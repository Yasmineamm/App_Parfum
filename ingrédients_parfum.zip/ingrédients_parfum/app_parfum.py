import streamlit as st
import fitz  # PyMuPDF

# === Fonction pour lire le texte d'un PDF ===
def extract_text_from_pdf(file):
    text = ""
    with fitz.open(stream=file.read(), filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text

# === Fonction pour structurer les ingrédients par ID ===
def parse_ingredients(text):
    data = {}
    lines = text.splitlines()
    current_id = None
    buffer = []

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line[0].isdigit():
            if current_id and buffer:
                joined = " ".join(buffer)
                all_ingredients = joined.replace('\n', '').split(',')
                data[current_id] = [ing.strip() for ing in all_ingredients if ing.strip()]
                buffer = []

            parts = line.split(' ', 1)
            current_id = parts[0]
            buffer.append(parts[1] if len(parts) > 1 else "")

        else:
            buffer.append(line)

    if current_id and buffer:
        joined = " ".join(buffer)
        all_ingredients = joined.replace('\n', '').split(',')
        data[current_id] = [ing.strip() for ing in all_ingredients if ing.strip()]

    return data

# === Interface Streamlit ===
st.title("🔍 Extracteur d'ingrédients de parfum")

uploaded_file = st.file_uploader("Téléversez un fichier PDF contenant les ingrédients", type=["pdf"])

if uploaded_file is not None:
    with st.spinner("Lecture du fichier..."):
        text = extract_text_from_pdf(uploaded_file)
        data = parse_ingredients(text)
        st.success("Fichier traité avec succès ✅")

    parfum_id = st.text_input("Entrez l'ID du parfum (ex: 4)")

    if parfum_id:
        if parfum_id in data:
            st.subheader(f"Ingrédients pour le parfum ID {parfum_id} :")
            ingredients_str = ", ".join(data[parfum_id])
            st.write(ingredients_str)
        else:
            st.warning("ID non trouvé dans le fichier.")