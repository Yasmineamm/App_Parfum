import subprocess
import sys
import os

def main():
    # Chemin vers votre script Streamlit (dans le même dossier que le .exe)
    streamlit_script = os.path.join(os.path.dirname(__file__), "app_parfum.py")
    subprocess.call([sys.executable, "-m", "streamlit", "run", streamlit_script])

if __name__ == "__main__":
    main()
    